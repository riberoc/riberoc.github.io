// Component-only plugin: no options needed, so no init() export required.
export { HeroBanner } from "./components/index"
