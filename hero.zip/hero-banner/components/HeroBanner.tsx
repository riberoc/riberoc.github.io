import { QuartzComponent, QuartzComponentConstructor, QuartzComponentProps } from "@quartz-community/types"

const HeroBanner: QuartzComponent = (props: QuartzComponentProps) => {
  const { fileData } = props
  const cover = fileData.frontmatter?.cover as string | undefined
  const title = fileData.frontmatter?.title ?? fileData.filePath?.split("/").pop()

  return <div style={{ background: "red", color: "white", padding: "1rem" }}>HERO DEBUG 2 cover={String(cover)} title={String(title)}</div>
}

export default (() => HeroBanner) satisfies QuartzComponentConstructor
