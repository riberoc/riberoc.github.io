// Component-only plugin: no options needed, so no init() export required.
// Quartz loads this via side-effect import per quartz-community/plugin-template docs.
export { HeroBanner } from "./components/index"
