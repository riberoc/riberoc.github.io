import { QuartzComponent, QuartzComponentConstructor, QuartzComponentProps } from "@quartz-community/types"
import style from "../styles/hero.scss"

// NOTE: in v4 this imported "./ArticleTitle" and "./ContentMeta" directly.
// In v5 those live in their own separate plugins (article-title, content-meta).
// To keep this plugin standalone, title + date/read-time are re-implemented
// inline below instead of importing another plugin's component.
// If you'd rather not duplicate that logic, disable the article-title and
// content-meta plugin entries in quartz.config.yaml and let this component
// handle both the cover and non-cover cases.

const HeroBanner: QuartzComponent = (props: QuartzComponentProps) => {
  const { fileData } = props
  const cover = fileData.frontmatter?.cover as string | undefined
  const title = fileData.frontmatter?.title ?? fileData.filePath?.split("/").pop()
  const date = fileData.dates?.modified ?? fileData.dates?.created

  const titleBlock = (
    <h1 class="article-title">{title}</h1>
  )
  const metaBlock = (
    <p class="content-meta">
      {date ? <time>{new Date(date).toLocaleDateString()}</time> : null}
    </p>
  )

  if (cover) {
    return (
      <div class="hero-banner-container">
        <div class="hero-banner-image" style={{ backgroundImage: `url(${cover})` }}>
          <div class="hero-banner-overlay">
            {titleBlock}
            {metaBlock}
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {titleBlock}
      {metaBlock}
    </>
  )
}

HeroBanner.css = style

export default (() => HeroBanner) satisfies QuartzComponentConstructor
